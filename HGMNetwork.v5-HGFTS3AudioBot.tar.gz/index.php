<?php
$ip = $_SERVER['REMOTE_ADDR'];

//====================================================
// #HGMNetwork.v5 Script Ucretiz AudioBot Paneli
// #Coded: HGMNetwork By HGM
//====================================================
//////////////////////////////////////////////////////
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
	<meta name="HGMNetwork By HGM" content="Ucretsiz AudioBot Sistemi">
	<script src='https://www.google.com/recaptcha/api.js?hl=tr'></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<title>HGMNetwork - Ucretsiz AudioBot Paneli</title>
</head>
<!-- HGMNetwork_Free_AudioBot_Script, Coded By HGMNetwork -->
<style type="text/css">
<!--

body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
        background-image: url('HGMNetwork_FreeAudio/HGFAudioBot_BackGroundImage.jpg');
        background-repeat: no-repeat;
}

.HGMNetwork_Rengarenk span{
    font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
    font-weight: bold;
    font-size: 70px;
    text-shadow: 1px 1px 0px #A3A3A3;
    display: inline-block;
}

.HGMNetwork_Rengarenk_font45 span{
    font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
    font-weight: bold;
    font-size: 45px;
    text-shadow: 1px 1px 0px #A3A3A3;
    display: inline-block;
}

.HGMNetwork_Rengarenk_font30 span{
    font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
    font-weight: bold;
    font-size: 30px;
    text-shadow: 1px 1px 0px #A3A3A3;
    display: inline-block;
}

.HGMNetwork_Button {
	border: none;
	color: transparent;
	padding: 16px 32px;
	text-aling: center;
	text-decoration: none;
	display: 16px;
	font-size: 16px;
	margin: 4px 2px;
	transition-duration: 0.4s;
	cursor: pointer;
}

.HGMNetwork_AnaButon {
	background-color: transparent;
	color: black
}

.HGMNetwork_AnaButon:hover {
	background-color: #008CBA;
	color: white;
}

input[type=text]{
    border:2px solid #aaa;
    border-radius:4px;
	background-color: #3C403C;
    margin:8px 0;
    outline:none;
    padding:8px;
    box-sizing:border-box;
    transition:.3s;
}

input[type=text]:hover{
    border-color:dodgerBlue;
    box-shadow:0 0 8px 0 dodgerBlue;
}

input[type=text]:focus{
    border-color:dodgerBlue;
    box-shadow:0 0 8px 0 dodgerBlue;
}

-->
</style>
<!-- HGMNetwork_Free_AudioBot_Script, Coded By HGMNetwork -->
<body>
<center><br><br>
<form name="input" action="olustur.php" method="post">
<div class="HGMNetwork_Rengarenk">
<span style="color:#ff0000">H</span><span style="color:#ff1100">G</span><span style="color:#ff2200">M</span><span style="color:#ff3300">N</span><span style="color:#ff4400">e</span><span style="color:#ff5500">t</span><span style="color:#ff6600">w</span><span style="color:#ff7700">o</span><span style="color:#ff8800">r</span><span style="color:#ff9900">k</span>
</div>
<br>
<div class="HGMNetwork_Rengarenk_font45">
<span style="color:#ff3200">U</span><span style="color:#ff6600">c</span><span style="color:#ff9900">r</span><span style="color:#ffcc00">e</span><span style="color:#ffff00">t</span><span style="color:#ccff00">s</span><span style="color:#99ff00">i</span><span style="color:#65ff00">z</span> <span style="color:#66ff00"></span> <span style="color:#00ff00">T</span><span style="color:#00ff33">S</span><span style="color:#00ff65">3</span><span style="color:#00ff99">A</span><span style="color:#00ffcb">u</span><span style="color:#00ffff">d</span><span style="color:#00cbff">i</span><span style="color:#0099ff">o</span><span style="color:#0065ff">B</span><span style="color:#0033ff">o</span><span style="color:#0000ff">t</span> <span style="color:#66ff00"></span> <span style="color:#6600ff">O</span><span style="color:#9800ff">l</span><span style="color:#cb00ff">u</span><span style="color:#ff00ff">s</span><span style="color:#ff00cb">t</span><span style="color:#ff0098">u</span><span style="color:#ff0066">r</span><span style="color:#ff0033">m</span><span style="color:#ff0000">a</span>
</div>
<br>
<div class="HGMNetwork_Rengarenk_font30">
<span style="color:#ff3200">H</span><span style="color:#ff6600">o</span><span style="color:#ff9900">s</span><span style="color:#ffcc00">t</span><span style="color:#ffff00">e</span><span style="color:#ccff00">d</span><span style="color:#99ff00">/</span><span style="color:#65ff00">S</span><span style="color:#32ff00">c</span><span style="color:#00ff00">r</span><span style="color:#00ff33">i</span><span style="color:#00ff65">p</span><span style="color:#00ff99">t</span><span style="color:#00ffcb">e</span><span style="color:#00ffff">d</span> <span style="color:#0099ff">B</span><span style="color:#0065ff">y</span><span style="color:#0033ff">:</span> <span style="color:#3300ff">H</span><span style="color:#6600ff">G</span><span style="color:#9800ff">M</span><span style="color:#cb00ff">N</span><span style="color:#ff00ff">e</span><span style="color:#ff00cb">t</span><span style="color:#ff0098">w</span><span style="color:#ff0066">o</span><span style="color:#ff0033">r</span><span style="color:#ff0000">k</span>
</div>
</div>
<br><br>
<font size="4"><b>Baglanilacak TS3 Adresi: </b>
<br>
<input type="text" name="HGMNetwork_Ts3AudioBot_TS3Adres" style="color:#7CFC00" value = "0.0.0.0" onblur = "if ( this.value=='' ) this.value = '0.0.0.0';" onfocus = " if ( this.value == '0.0.0.0' ) this.value = '';">
<b><font size=4>:</font></b>
<input type="text" name="HGMNetwork_Ts3AudioBot_TS3port" style="color:#7CFC00" value = "9987" onblur = "if ( this.value=='' ) this.value = '9987';" onfocus = " if ( this.value == '9987' ) this.value = '';">

<br><br>
<font size="4"><b>Yetkili TS3 Kimlik Kodu [UID]: </b>
<br>
<input type="text" name="HGMNetwork_Ts3AudioBot_YetkiliUID" font size="30" style="color:#7CFC00" value = "fnFHDr1DfeTsC7XzHJOxNAsE1bo=" onblur = "if ( this.value=='' ) this.value = 'fnFHDr1DfeTsC7XzHJOxNAsE1bo=';" onfocus = " if ( this.value == 'fnFHDr1DfeTsC7XzHJOxNAsE1bo=' ) this.value = '';">
<br><br>

<button type="sumbit" class="HGMNetwork_Button HGMNetwork_AnaButon">TS3AudioBot Olustur.</button>
<br><br>
</a>
<br><br>
</form>
<font size=4><b>Kullandiginiz Ip:</b> <font color="red"> <font size=2> <b>[<?php echo $ip; ?>]</b></font><font color=#FFFFFF><font size=2> &nbsp;<b>(Guvenlik Kosullari Nedeniyle<font color =red> Kayit Altindadir..!</font>)</font><br><br>
</body>
</html>