<?php
if (isset($_POST['g-recaptcha-response'])) {
    $HGMNet_captcha = $_POST['g-recaptcha-response'];
}
if (!$HGMNet_captcha) {
    exit('<p><hr><font color=red><font size=5><b>reCAPTCHA Bilgileri Hatali, Lutfen Tekrar Deneyin..!</font></p><hr></b>');
}
$HGMNet_Robot_Kontrol = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret='.$HGMNetwork_reCAPTCHA_GizliKey.'&response=" . $HGMNet_captcha . "&remoteip=" . $_SERVER['REMOTE_ADDR']);
if ($HGMNet_Robot_Kontrol.success == false) {
    exit('<p><hr><font color=red><font size=5><b>reCAPTCHA Bilgileri Hatali, Lutfen Tekrar Deneyin..!</font></p><hr></b>');
}

set_include_path("HGMNetwork_FreeAudio/");
include('Net/SSH2.php');

$HGMNetwork_TS3AudioBot_TSAdresi = $_POST['HGMNetwork_Ts3AudioBot_TS3Adres'];
$HGMNetwork_Ts3AudioBot_YetkiliID = $_POST['HGMNetwork_Ts3AudioBot_YetkiliUID'];
$HGMNetwork_TS3AudioBot_TSPortu = $_POST['HGMNetwork_Ts3AudioBot_TS3port'];
$ip = $_SERVER['REMOTE_ADDR'];

$HGMNetwork_AudioBot_RandomPort = substr(str_shuffle("123456789"), 0, 4);
$HGMNetwork_Random_Sifre = substr(str_shuffle("1234567890qwertQWERTasdfgASDFGzxcvbZXCVB"), 0, 11);
sleep(1);

//////////////////////////////////////////////////////
//====================================================
// #HGMNetwork.v5 Script Ucretiz AudioBot Paneli
// #Coded: HGMNetwork By HGM
//====================================================
//////////////////////////////////////////////////////
//====================================================
//====================================================
//////////////////////////////////////////////////////
//====================================================
// [HGMNetwork] #Bu Bolumde Sunucu Bilgileri Bulunur;
//====================================================
//====================================================
//////////////////////////////////////////////////////
//====================================================
$HGMNetwork_Anadizin = "/home/sinusbot/HGMNetwork/"; // Gerekmedikce Ellemeyin..!
//====================================================
//////////////////////////////////////////////////////

$ssh = new Net_SSH2(''.$HGMNetwork_TS3AudioBot_MakineIp.'');
if (!$ssh->login(''.$HGMNetwork_Server_Kullanici_Adi.'', ''.$HGMNetwork_Server_Parolasi.''))
{
    exit('<p><hr><font color=red><font size=5><b>Sunucu Bilgileri Hatali, Lutfen Tekrar Deneyin..!</font></p><hr></b>');
}else{
$ssh->exec('cd '.$HGMNetwork_Anadizin.' && sudo ./HGMNetwork_AudioFiles -HG_78360655523203743702504086519096186347556072275364');
$ssh->exec('mkdir -p /opt/TS3AudioBot'.$HGMNetwork_AudioBot_RandomPort.'/');
$ssh->exec('cp -r /opt/HGMNet_TS3AudioBotFiles/* /opt/TS3AudioBot'.$HGMNetwork_AudioBot_RandomPort.'/');
$ssh->exec('cd '.$HGMNetwork_Anadizin.' && cp -r HGMNetwork_Audio_Konfig /opt/TS3AudioBot'.$HGMNetwork_AudioBot_RandomPort.'/');
$ssh->exec('cd /opt/TS3AudioBot'.$HGMNetwork_AudioBot_RandomPort.'/ && chmod 777 HGMNetwork_Audio_Konfig');
$ssh->exec('cd /opt/TS3AudioBot'.$HGMNetwork_AudioBot_RandomPort.'/ && sudo ./HGMNetwork_Audio_Konfig -HG_77521885848194575355059327430717545850727574779160');
$ssh->exec('cd /opt/TS3AudioBot'.$HGMNetwork_AudioBot_RandomPort.'/ && sudo ./HGMNetwork_Audio_Konfig -HG_27589236542425801357920441188286104832782484786634');
$ssh->exec('cd /opt/TS3AudioBot'.$HGMNetwork_AudioBot_RandomPort.'/ && sudo ./HGMNetwork_Audio_Konfig -HG_01032357687318866547672527509013115605042898092493');
$ssh->exec('cd /opt/TS3AudioBot'.$HGMNetwork_AudioBot_RandomPort.'/ && sudo ./HGMNetwork_Audio_Konfig -HG_01909912116873629053044503293276688212245136842941 '.$HGMNetwork_TS3AudioBot_TSAdresi.' '.$HGMNetwork_TS3AudioBot_TSPortu.'');
$ssh->exec('cd /opt/TS3AudioBot'.$HGMNetwork_AudioBot_RandomPort.'/ && sudo ./HGMNetwork_Audio_Konfig -HG_38233956422422857982386989019169910344914825964051 '.$HGMNetwork_AudioBot_RandomPort.'');
$ssh->exec('cd /opt/TS3AudioBot'.$HGMNetwork_AudioBot_RandomPort.'/ && sudo ./HGMNetwork_Audio_Konfig -HG_51268984542269340825470153457279950334534539475009 '.$HGMNetwork_Ts3AudioBot_YetkiliID.'');
$ssh->exec('cd /opt/TS3AudioBot'.$HGMNetwork_AudioBot_RandomPort.'/ && sudo ./HGMNetwork_Audio_Konfig -HG_72533165465380518091164011504269322427065006093505 '.$HGMNetwork_TS3AudioBot_TSAdresi.' '.$HGMNetwork_TS3AudioBot_TSPortu.'');
$ssh->exec('cd /opt/TS3AudioBot'.$HGMNetwork_AudioBot_RandomPort.'/ && sudo ./HGMNetwork_Audio_Konfig -HG_74933506063069492745358100337681137077784134078236 '.$HGMNetwork_TS3AudioBot_TSAdresi.' '.$HGMNetwork_TS3AudioBot_TSPortu.'');
$ssh->exec('cd /opt/TS3AudioBot'.$HGMNetwork_AudioBot_RandomPort.'/ && rm -rf HGMNetwork_Audio_Konfig');
$ssh->exec('cd /opt/TS3AudioBot'.$HGMNetwork_AudioBot_RandomPort.'/ && su root -c "screen -A -m -d -S HGMTsAudioBot'.$HGMNetwork_AudioBot_RandomPort.' sudo dotnet TS3AudioBot.dll --non-interactive"');

}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
	<meta name="HGMNetwork By HGM" content="Ucretsiz AudioBot Paneli">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<title>HGMNetwork - Ucretsiz AudioBot Paneli</title>
</head>
<!-- HGMNetwork_Free_TS3AudioBot_Script, Coded By HGMNetwork -->
<style type="text/css">
<!--

body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
        background-image: url('HGMNetwork_FreeAudio/HGFAudioBot_BackGroundImage.jpg');
        background-repeat: no-repeat;
}

.HGMNetwork_Rengarenk span{
    font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
    font-weight: bold;
    font-size: 70px;
    text-shadow: 1px 1px 0px #A3A3A3;
    display: inline-block;
}

.HGMNetwork_Rengarenk_font45 span{
    font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
    font-weight: bold;
    font-size: 45px;
    text-shadow: 1px 1px 0px #A3A3A3;
    display: inline-block;
}

.HGMNetwork_Rengarenk_font30 span{
    font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
    font-weight: bold;
    font-size: 30px;
    text-shadow: 1px 1px 0px #A3A3A3;
    display: inline-block;
}

.HGMNetwork_Buton{
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.HGMNet_Buton{
  display: block;
  width: 200px;
  height: 40px;
  line-height: 40px;
  font-size: 18px;
  font-family: sans-serif;
  text-decoration: none;
  color: #333;
  border: 2px solid #333;
  letter-spacing: 2px;
  text-align: center;
  position: relative;
  transition: all .35s;
}

.HGMNet_Buton span{
  position: relative;
  z-index: 2;
}

.HGMNet_Buton:after{
  position: absolute;
  content: "";
  top: 0;
  left: 0;
  width: 0;
  height: 100%;
  background: #ff003b;
  transition: all .35s;
}

.HGMNet_Buton:hover{
  color: #fff;
}

.HGMNet_Buton:hover:after{
  width: 100%;
}

-->
</style>
<!-- HGMNetwork_Free_TS3AudioBot_Script, Coded By HGMNetwork -->

<body>
<center>
<br><br>

<div class="HGMNetwork_Rengarenk">
<span style="color:#ff0000">H</span><span style="color:#ff1100">G</span><span style="color:#ff2200">M</span><span style="color:#ff3300">N</span><span style="color:#ff4400">e</span><span style="color:#ff5500">t</span><span style="color:#ff6600">w</span><span style="color:#ff7700">o</span><span style="color:#ff8800">r</span><span style="color:#ff9900">k</span>
</div>
<br>
<div class="HGMNetwork_Rengarenk_font45">
<span style="color:#ff3200">U</span><span style="color:#ff6600">c</span><span style="color:#ff9900">r</span><span style="color:#ffcc00">e</span><span style="color:#ffff00">t</span><span style="color:#ccff00">s</span><span style="color:#99ff00">i</span><span style="color:#65ff00">z</span> <span style="color:#66ff00"></span> <span style="color:#00ff00">T</span><span style="color:#00ff33">S</span><span style="color:#00ff65">3</span><span style="color:#00ff99">A</span><span style="color:#00ffcb">u</span><span style="color:#00ffff">d</span><span style="color:#00cbff">i</span><span style="color:#0099ff">o</span><span style="color:#0065ff">B</span><span style="color:#0033ff">o</span><span style="color:#0000ff">t</span> <span style="color:#66ff00"></span> <span style="color:#6600ff">O</span><span style="color:#9800ff">l</span><span style="color:#cb00ff">u</span><span style="color:#ff00ff">s</span><span style="color:#ff00cb">t</span><span style="color:#ff0098">u</span><span style="color:#ff0066">r</span><span style="color:#ff0033">m</span><span style="color:#ff0000">a</span>
</div>
<br>
<div class="HGMNetwork_Rengarenk_font30">
<span style="color:#ff3200">H</span><span style="color:#ff6600">o</span><span style="color:#ff9900">s</span><span style="color:#ffcc00">t</span><span style="color:#ffff00">e</span><span style="color:#ccff00">d</span><span style="color:#99ff00">/</span><span style="color:#65ff00">S</span><span style="color:#32ff00">c</span><span style="color:#00ff00">r</span><span style="color:#00ff33">i</span><span style="color:#00ff65">p</span><span style="color:#00ff99">t</span><span style="color:#00ffcb">e</span><span style="color:#00ffff">d</span> <span style="color:#0099ff">B</span><span style="color:#0065ff">y</span><span style="color:#0033ff">:</span> <span style="color:#3300ff">H</span><span style="color:#6600ff">G</span><span style="color:#9800ff">M</span><span style="color:#cb00ff">N</span><span style="color:#ff00ff">e</span><span style="color:#ff00cb">t</span><span style="color:#ff0098">w</span><span style="color:#ff0066">o</span><span style="color:#ff0033">r</span><span style="color:#ff0000">k</span>
</div>

<br><br>
<?php
echo "<font color='#7CFC00'><font size=3><strong>TS3AudioBot Basariyla Olusturuldu..!</strong><br>Giris-Bilgileri; <br><br>Panel URL: <font color=red> http://".$HGMNetwork_TS3AudioBot_MakineIp.":".$HGMNetwork_AudioBot_RandomPort."<br><font color='#7CFC00'>Bot Nicki:<font color=red> HGMNetwork.AudioBot<br><font color='#7CFC00'>Sifre Icin;<br><font color=red>[Bota Ozelden '!api key' Yazin].";
?>

<br><br>
<div class="HGMNet_Buton">
<a href="index.php"><font color=black><span>Geri Donme</span></a>
</div>

<br><br>
<font size=4><b>Kullandiginiz Ip:</b> <font color="red"> <font size=2> <b>[<?php echo $ip; ?>]</b></font><font color=#FFFFFF><font size=2> &nbsp;<b>(Guvenlik Kosullari Nedeniyle<font color =red> Kayit Altindadir..!</font>)</font><br><br>
</body>
</html>